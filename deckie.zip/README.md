# Deckie

### Hearthstone deck manager.

Deckie makes it easy to view any of your decks (or search for a card) without leaving the current page you're on.

Have you ever seen a deck screenshot online and wanted to compare it to one of yours?  If your store your decks on a website you have to open another tab, navigate to the site and resize your windows to get a side by side look.  With Deckie it's just one click.

Maybe you're not familiar with a card and would like to know more about it?  No more need to do three or four steps when you can get the same information from Deckie.